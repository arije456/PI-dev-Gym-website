<?PHP
 class Categorie{
		private  $id ;
		private  $nom ;
		private  $date_creation ;
        private  $description ;

 function __construct( $nom,  $date_creation,  $description ){
			
			$this->nom=$nom;
			$this->date_creation=$date_creation;
			$this->description=$description;
        }
        
        function getId(){
			return $this->id;
		}
		function getNom(){
			return $this->nom;
        }
        function setNom( $nom){
			$this->nom=$nom;
        }
        
        function getDate_creation(){
			return $this->date_creation;
        }
        function setDate_creation($date_creation) {
			$this->date_creation=$date_creation;
        }

        function setDescription( $description){
			$this->description=$description;
        }
        function getDescription(){
			return $this->description;
        }
        
    }
?>


		