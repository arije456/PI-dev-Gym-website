<?PHP
		require_once "../config.php";
	require_once '../model/Categorie.php';
	class CategorieC {
		
		function ajouterCategorie($Categorie){
			$sql="INSERT INTO Categorie (nom, date_creation, description) 
			VALUES (:nom,:date_creation,:description)";
			$db = config::getConnexion();
			try{
				$query = $db->prepare($sql);
			
				$query->execute([
					'nom' => $Categorie->getNom(),
					'date_creation' => $Categorie->getDate_creation(),
					'description' => $Categorie->getDescription()
				]);	
				
				
			}
			catch (Exception $e){
				echo 'Erreur: '.$e->getMessage();
			}			
        }
        
        function afficherCategories(){
			
			$sql="SELECT * FROM Categorie";
			$db = config::getConnexion();
			try{
				$liste = $db->query($sql);
				return $liste;
			}
			catch (Exception $e){
				die('Erreur: '.$e->getMessage());
			}	
        }
        
        function supprimerCategorie($id){
			$sql="DELETE FROM Categorie WHERE id_categorie_planning= :id_categorie_planning";
			$db = config::getConnexion();
			$req=$db->prepare($sql);
			$req->bindValue(':id_categorie_planning',$id);
			try{
				$req->execute();
			}
			catch (Exception $e){
				die('Erreur: '.$e->getMessage());
			}
		}
		function modifierCategorie($Categorie, $id){
			try {
				$db = config::getConnexion();
				$query = $db->prepare(
					'UPDATE Categorie SET 
						nom = :nom, 
						date_creation = :date_creation,
						description = :description
					WHERE id_categorie_planning = :id_categorie_planning'
				);
				$query->execute([
					'nom' => $Categorie->getNom(),
					'date_creation' => $Categorie->getDate_creation(),
					'description' => $Categorie->getDescription(),
					'id_categorie_planning' => $id
				]);
				?>
				<script> alert("updated successfully!!"); </script>
				<?php
				echo $query->rowCount() . " records UPDATED successfully <br>";
			} catch (PDOException $e) {
				$e->getMessage();
			}
		}
		function recupererCategorie($id){
			$sql="SELECT * from Categorie where id_categorie_planning=$id";
			$db = config::getConnexion();
			try{
				$query=$db->prepare($sql);
				$query->execute();

				$user=$query->fetch();
				return $user;
			}
			catch (Exception $e){
				die('Erreur: '.$e->getMessage());
			}
		}

		function recupererCategorie1($id){
			$sql="SELECT * from Categorie where id_categorie_planning=$id";
			$db = config::getConnexion();
			try{
				$query=$db->prepare($sql);
				$query->execute();
				
				$user = $query->fetch(PDO::FETCH_OBJ);
				return $user;
			}
			catch (Exception $e){
				die('Erreur: '.$e->getMessage());
			}
		}

		function rechercheCateg($key)
	{
		$sql = "SELECT * FROM Categorie WHERE nom LIKE '%$key%'  OR date_creation LIKE '%$key%' OR description LIKE '%$key%'";

		$db = config::getConnexion();
		try {
			$liste = $db->query($sql);//retourne le resultat en un objet PDOstatement
			//var_dump($liste) ; die;
			return $liste;
		} catch (Exception $e) {
			die('Erreur: ' . $e->getMessage());
		}
	}
		
	}
        



	?>